// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails";
import "controllers";

var cart_2 = document.getElementById("cart-2");
if(cart_2.id == "cart-2") {
  document.getElementById("button-cart-2").value = "AVAILABLE IN CART";
}
var cart_3 = document.getElementById("cart-3");
if(cart_3.id == "cart-3") {
  document.getElementById("button-cart-3").value = "AVAILABLE IN CART";
}
var cart_4 = document.getElementById("cart-4");
if(cart_4.id == "cart-4") {
  document.getElementById("button-cart-4").value = "AVAILABLE IN CART";
}
var cart_5 = document.getElementById("cart-5");
if(cart_5.id == "cart-5") {
  document.getElementById("button-cart-5").value = "AVAILABLE IN CART";
}
var cart_6 = document.getElementById("cart-6");
if(cart_6.id == "cart-6") {
  document.getElementById("button-cart-6").value = "AVAILABLE IN CART";
}
var cart_7 = document.getElementById("cart-7");
if(cart_7.id == "cart-7") {
  document.getElementById("button-cart-7").value = "AVAILABLE IN CART";
}
var cart_8 = document.getElementById("cart-8");
if(cart_8.id == "cart-8") {
  document.getElementById("button-cart-8").value = "AVAILABLE IN CART";
}
var cart_9 = document.getElementById("cart-9");
if(cart_9.id == "cart-9") {
  document.getElementById("button-cart-9").value = "AVAILABLE IN CART";
}
var cart_10 = document.getElementById("cart-10");
if(cart_10.id == "cart-10") {
  document.getElementById("button-cart-10").value = "AVAILABLE IN CART";
}
var cart_11 = document.getElementById("cart-11");
if(cart_11.id == "cart-11") {
  document.getElementById("button-cart-11").value = "AVAILABLE IN CART";
}

//-------------------------------------------------------------

document.getElementById("button-cart-2").onclick = function() {
  document.getElementById("button-cart-2").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-3").onclick = function() {
  document.getElementById("button-cart-3").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-4").onclick = function() {
  document.getElementById("button-cart-4").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-5").onclick = function() {
  document.getElementById("button-cart-5").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-6").onclick = function() {
  document.getElementById("button-cart-6").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-7").onclick = function() {
  document.getElementById("button-cart-7").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-8").onclick = function() {
  document.getElementById("button-cart-8").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-9").onclick = function() {
  document.getElementById("button-cart-9").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-10").onclick = function() {
  document.getElementById("button-cart-10").value = "AVAILABLE IN CART";
};
document.getElementById("button-cart-11").onclick = function() {
  document.getElementById("button-cart-11").value = "AVAILABLE IN CART";
};
//-------------------------------------------------------
document.getElementById("cart-2").onclick = function() {
  document.getElementById("button-cart-2").value = "ADD TO CART";
};
document.getElementById("cart-3").onclick = function() {
  document.getElementById("button-cart-3").value = "ADD TO CART";
};
document.getElementById("cart-4").onclick = function() {
  document.getElementById("button-cart-4").value = "ADD TO CART";
};
document.getElementById("cart-5").onclick = function() {
  document.getElementById("button-cart-5").value = "ADD TO CART";
};
document.getElementById("cart-6").onclick = function() {
  document.getElementById("button-cart-6").value = "ADD TO CART";
};
document.getElementById("cart-7").onclick = function() {
  document.getElementById("button-cart-7").value = "ADD TO CART";
};
document.getElementById("cart-8").onclick = function() {
  document.getElementById("button-cart-8").value = "ADD TO CART";
};
document.getElementById("cart-9").onclick = function() {
  document.getElementById("button-cart-9").value = "ADD TO CART";
};
document.getElementById("cart-10").onclick = function() {
  document.getElementById("button-cart-10").value = "ADD TO CART";
};
document.getElementById("cart-11").onclick = function() {
  document.getElementById("button-cart-11").value = "ADD TO CART";
};

